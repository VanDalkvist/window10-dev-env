gusztavvargadr_windows_updates '' do
  action [:enable, :start, :configure, :install]
end
