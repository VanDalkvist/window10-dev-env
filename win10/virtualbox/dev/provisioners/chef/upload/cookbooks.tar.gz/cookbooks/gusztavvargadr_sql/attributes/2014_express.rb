default['gusztavvargadr_sql']['2014_express'] = {
  'installer_file_name' => 'installer.exe',
  'installer_file_url' => 'http://download.microsoft.com/download/E/A/E/EAE6F7FC-767A-4038-A954-49B8B05D04EB/ExpressAndTools%2064BIT/SQLEXPRWT_x64_ENU.exe',
}
