name 'gusztavvargadr_packer_w10e'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Packer Windows 10 Enterprise'
long_description 'Installs/Configures Packer Windows 10 Enterprise'
version '0.0.0'

depends 'gusztavvargadr_packer_w'
