default['gusztavvargadr_docker']['images'] = {
}
