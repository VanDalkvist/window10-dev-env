gusztavvargadr_vs_2017 'professional' do
  action :install
end
