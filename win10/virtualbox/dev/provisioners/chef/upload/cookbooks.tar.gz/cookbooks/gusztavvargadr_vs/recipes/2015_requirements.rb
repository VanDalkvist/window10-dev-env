gusztavvargadr_windows_features '' do
  features_options node['gusztavvargadr_vs']['2015_requirements']['features']
end
