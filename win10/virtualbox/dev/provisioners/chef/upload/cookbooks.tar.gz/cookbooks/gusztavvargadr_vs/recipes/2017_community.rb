gusztavvargadr_vs_2017 'community' do
  action :install
end
