gusztavvargadr_windows_features '' do
  features_options node['gusztavvargadr_sql']['2014_requirements']['features']
end
