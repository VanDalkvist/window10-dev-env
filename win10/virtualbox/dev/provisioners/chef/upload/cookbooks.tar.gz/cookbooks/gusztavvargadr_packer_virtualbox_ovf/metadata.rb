name 'gusztavvargadr_packer_virtualbox_ovf'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Packer Virtualbox OVF'
long_description 'Installs/Configures Packer Virtualbox OVF'
version '0.0.0'

depends 'gusztavvargadr_virtualbox'
