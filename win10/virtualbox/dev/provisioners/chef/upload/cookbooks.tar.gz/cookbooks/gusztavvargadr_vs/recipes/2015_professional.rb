gusztavvargadr_vs_2015 'professional' do
  action :install
end
