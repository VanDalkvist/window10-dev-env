include_recipe 'gusztavvargadr_packer_w::install'
include_recipe 'gusztavvargadr_sql::2017_developer'
include_recipe 'gusztavvargadr_sql::2017_ssms'
