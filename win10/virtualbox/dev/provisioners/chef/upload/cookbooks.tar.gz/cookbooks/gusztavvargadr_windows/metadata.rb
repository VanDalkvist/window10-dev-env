name 'gusztavvargadr_windows'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Windows'
long_description 'Installs/Configures Windows'
version '0.0.0'

depends 'windows', '~> 3.1.1'
