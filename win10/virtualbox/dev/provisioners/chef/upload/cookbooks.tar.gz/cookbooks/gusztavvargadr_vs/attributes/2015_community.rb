default['gusztavvargadr_vs']['2015_community'] = {
  'installer_file_url' => 'https://onedrive.live.com/download?cid=EFF41AD5731FA3EA&resid=EFF41AD5731FA3EA%21706722&authkey=ACa69dL0LNU0GiM',
}
