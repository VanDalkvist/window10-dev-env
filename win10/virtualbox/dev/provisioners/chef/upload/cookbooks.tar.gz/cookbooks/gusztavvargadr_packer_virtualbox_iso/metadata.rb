name 'gusztavvargadr_packer_virtualbox_iso'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Packer Virtualbox ISO'
long_description 'Installs/Configures Packer Virtualbox ISO'
version '0.0.0'

depends 'gusztavvargadr_virtualbox'
