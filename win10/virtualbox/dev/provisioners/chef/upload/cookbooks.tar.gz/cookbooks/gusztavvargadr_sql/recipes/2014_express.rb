gusztavvargadr_sql_2014 'express' do
  action :install
end
