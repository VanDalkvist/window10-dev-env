name 'gusztavvargadr_iis'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures IIS'
long_description 'Installs/Configures IIS'
version '0.0.0'

depends 'gusztavvargadr_windows'
