gusztavvargadr_windows_updates '' do
  action :install
end
