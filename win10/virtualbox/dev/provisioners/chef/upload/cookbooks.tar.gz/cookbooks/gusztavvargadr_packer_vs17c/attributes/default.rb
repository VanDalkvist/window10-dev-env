default['gusztavvargadr_packer_vs17c']['default'] = {
  'chocolatey_packages' => {
    'resharper-ultimate-all' => {
      'version' => '2017.3.5',
      'install' => {
        'params' => '"\'/PerMachine\'"',
      },
      'elevated' => true,
    },
    'resharper-clt' => {
      'version' => '2017.3.5',
      'elevated' => true,
    },
  },
}
