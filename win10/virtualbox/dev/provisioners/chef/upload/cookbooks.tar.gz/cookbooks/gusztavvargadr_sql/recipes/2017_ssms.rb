gusztavvargadr_windows_native_packages '' do
  native_packages_options node['gusztavvargadr_sql']['2017_ssms']['native_packages']
end
