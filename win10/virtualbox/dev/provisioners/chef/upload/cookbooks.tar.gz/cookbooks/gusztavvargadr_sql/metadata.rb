name 'gusztavvargadr_sql'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures SQL Server'
long_description 'Installs/Configures SQL Server'
version '0.0.0'

depends 'gusztavvargadr_windows'
