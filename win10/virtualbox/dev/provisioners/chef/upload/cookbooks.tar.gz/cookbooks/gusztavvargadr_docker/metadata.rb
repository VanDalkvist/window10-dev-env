name 'gusztavvargadr_docker'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Docker'
long_description 'Installs/Configures Docker'
version '0.0.0'

depends 'gusztavvargadr_windows'
