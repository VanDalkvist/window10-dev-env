default['gusztavvargadr_sql']['2017_developer'] = {
  'installer_iso_url' => 'https://download.microsoft.com/download/E/F/2/EF23C21D-7860-4F05-88CE-39AA114B014B/SQLServer2017-x64-ENU-Dev.iso',
}
