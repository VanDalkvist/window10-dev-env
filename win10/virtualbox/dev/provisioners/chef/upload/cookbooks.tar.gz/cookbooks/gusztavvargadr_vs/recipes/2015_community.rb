gusztavvargadr_vs_2015 'community' do
  action :install
end
