name 'gusztavvargadr_packer_w'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Packer Windows'
long_description 'Installs/Configures Packer Windows'
version '0.0.0'

depends 'gusztavvargadr_windows'
