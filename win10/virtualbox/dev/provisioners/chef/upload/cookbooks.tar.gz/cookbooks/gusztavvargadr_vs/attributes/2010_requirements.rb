default['gusztavvargadr_vs']['2015_requirements'] = {
  'features' => {
    'NetFx3' => {},
  },
}
