name 'gusztavvargadr_vs'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures Visual Studio'
long_description 'Installs/Configures Visual Studio'
version '0.0.0'

depends 'gusztavvargadr_windows'
