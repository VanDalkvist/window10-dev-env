name 'gusztavvargadr_virtualbox'
maintainer 'Gusztáv Varga'
maintainer_email 'me@gusztavvargadr.me'
license 'MIT'
description 'Installs/Configures VirtualBox'
long_description 'Installs/Configures VirtualBox'
version '0.0.0'

depends 'gusztavvargadr_windows'
