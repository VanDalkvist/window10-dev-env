gusztavvargadr_sql_2017 'developer' do
  action :install
end
