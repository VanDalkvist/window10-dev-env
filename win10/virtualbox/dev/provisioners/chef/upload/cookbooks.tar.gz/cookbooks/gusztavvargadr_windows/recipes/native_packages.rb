gusztavvargadr_windows_native_packages '' do
  native_packages_options node['gusztavvargadr_windows']['native_packages']
  action :install
end
