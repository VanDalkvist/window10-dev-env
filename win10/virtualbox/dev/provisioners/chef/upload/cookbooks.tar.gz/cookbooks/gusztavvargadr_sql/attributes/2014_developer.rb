default['gusztavvargadr_sql']['2014_developer'] = {
  'installer_file_name' => 'installer.iso',
  'installer_file_url' => 'https://onedrive.live.com/download?cid=EFF41AD5731FA3EA&resid=EFF41AD5731FA3EA%21706519&authkey=ANXzO_6DLQeGJco',
}
