gusztavvargadr_vs_2010 'professional' do
  action :install
end
