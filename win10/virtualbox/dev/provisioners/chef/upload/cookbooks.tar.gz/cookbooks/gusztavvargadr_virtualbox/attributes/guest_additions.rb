default['gusztavvargadr_virtualbox']['guest_additions'] = {
  'version' => '5.2.8',
}
