default['gusztavvargadr_sql']['2014_requirements'] = {
  'features' => {
    'NetFx3' => {},
  },
}
