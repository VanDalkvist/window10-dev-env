gusztavvargadr_windows_files '' do
  files_options node['gusztavvargadr_windows']['files']
  action :create
end
