gusztavvargadr_sql_2014 'developer' do
  action :install
end
