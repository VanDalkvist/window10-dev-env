default['gusztavvargadr_vs']['2015_professional'] = {
  'installer_file_url' => 'https://onedrive.live.com/download?cid=EFF41AD5731FA3EA&resid=EFF41AD5731FA3EA%21706720&authkey=AP9C3_NOYmJxU9A',
}
